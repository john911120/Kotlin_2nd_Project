/*
    main함수의 매개변수 사용해보기
    Kotlin
 */

fun main(args: Array<String>) {
    println(args[0])
    println(args[1])
    println(args[2])
}