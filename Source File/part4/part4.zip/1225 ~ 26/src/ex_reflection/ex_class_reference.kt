package ex_reflection

import kotlin.reflect.KClass

/*
    함수에서 전달받은 클래스에 대한 정보를 KClass프로퍼티를 통해서 분석 가능하다.
    전달받은 클래스 레퍼런스가 MyClass이고 MyClass를 open만 추가해서 선언했으므로 isOpen 프로퍼티에 의한 결과값만
    true이고 나머지는 false이다.
 */

open class MyClass

fun someFun(arg: KClass<*>){
    println("class Info ....")
    println("isAbstract : ${arg.isAbstract}")
    println("isCompanion : ${arg.isCompanion}")
    println("isData : ${arg.isData}")
    println("isFinal : ${arg.isFinal}")
    println("isInner : ${arg.isInner}")
    println("isOpen : ${arg.isOpen}")
    println("isSealed : ${arg.isSealed}")
}

fun main() {
    someFun(MyClass::class)
}