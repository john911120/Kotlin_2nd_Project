package ex_variance

/*
    Sub와 Super는 클래스이면서 타입으로도 사용이 되므로 타입 캐스팅은 가능하지만
    MyClass<Sub>와 MyClass<Super>는 그 자체가 클래스가 아니다. 단지 제네릭을 사용해서
    타입으로 만 사용이 되고 일반 클래스의 상하위 관계에 의한 캐스팅은 안된다.
 */

open class Super1

class Sub1: Super()

class MyClass<T>

fun main() {
    val obj = MyClass<Sub1>()

    // val obj2: MyClass<Super1> = obj
}