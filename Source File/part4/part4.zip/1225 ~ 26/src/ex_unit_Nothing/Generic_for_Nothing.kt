package ex_unit_Nothing

/*
    null 이외의 다른 데이터를 대입 할 수 없어서 타입으로 의미는 없어보이지만
    다른 어떤 프로퍼티에도 대입이 가능한 것이 바로 Nothing이다.
    즉, null이외에 다른 어떤 타입의 데이터도 Nothing 타입에 대입을 할 수 없지만
    반대로 Nothing타입의 데이터는 어떠한 타입에도 대입이 가능하다.

    타입 측면에서 보면 Any와 정반대의 개념이다. 타입을 상하위 관계로 보면 Any는 최상위 타입이라면
    Nothing은 최하위 타입이다.

    그런데 잘못 알고 있는것은 Nothing타입의 프로퍼티를 다른 모든 타입에 대입이 가능하더라도 Nothing자체가
    Null만 대입 가능하므로 아무 의미 없어보이지만 제네릭에서 사용하면 의미가 있다. Varience라는 키워드에서
    covarience와 contravariance으로 나뉘는데 contravariance 부분에 쓰이면 유용하다.

    in 어노테이션을 사용했으므로 이곳에는 어떠한 제네릭 타입도 대입 가능하다. 즉, 모든 제네릭 타입으로 선언된
    클래스의 객체를 전달 할 수 있다.
 */
/*
val myVal1: Nothing? = null

val myVal2: Int? = myVal1
val myVal3: String? = myVal1
*/

class MyClass1<T>

fun someFun(arg: MyClass1<in Nothing>) { }

fun main() {
    someFun(MyClass1<Int>())
    someFun(MyClass1<String>())
}