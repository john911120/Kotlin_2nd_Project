package ex_unit_Nothing

/*
    Nothing의 활용법은 2가지의 상황에서 사용이 된다.
    1. 함수의 반환 타입을 Nothing으로 선언 하여서 이 함수는 반환이 없다는 것을 명시적으로 보여주는것이 가능하다.
    2. 함수를 Nothing타입으로 선언하여 프로그램의 유지보수 관점에서 코드 분석이 쉬워진다.

    함수의 반환값이 없거나 함수가 절대 반환하지 않는다는 것을 명시적으로 반환하는 것을 의미한다.

    이 처럼 특정 함수가 무언가를 절대 반환하지 않거나 반환하더라도 프로그램에서 의미 있는 데이터가
    아니라는 것을 명시적으로 보여주는 것이다.
 */

fun myFun(): Nothing {
    while (true) {
        //....
    }
}
/*
fun myFun2(): Nothing? {
    return null
}

fun myFun3(): Nothing {
    throw Exception()
}
 */