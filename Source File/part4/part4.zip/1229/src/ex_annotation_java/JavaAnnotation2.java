package ex_annotation_java;

public @interface JavaAnnotation2 {
    int value();
    String strValue();
}
