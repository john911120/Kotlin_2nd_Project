package ex_annotation_java;

public @interface JavaAnnotation3 {
    int[] value();
    String[] strValue();
}
