package ex_generic_Constraint

/*
    여러개의 제약
    MyClass<MyHandler2>으로 선언했는데 MyHandler2가 MyInterface1만 구현한 클래스이므로
    컴파일 에러가 발생한다.
 */

interface MyInterface1
interface MyInterface2

class MyHandler1: MyInterface1, MyInterface2

class MyHandler2 : MyInterface1

class MyClass<T> where T: MyInterface1, T: MyInterface2{

}

fun main() {
    val obj = MyClass<MyHandler1>()

   // val obj2 = MyClass<MyHandler2>()
}