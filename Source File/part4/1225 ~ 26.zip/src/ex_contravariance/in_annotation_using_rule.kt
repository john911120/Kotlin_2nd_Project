package ex_contravariance

open class Super

class Sub: Super()

class MyClass<in T>() {
    //val myVal: T? = null
    //val myVal2: T? = null

   /* fun myFun(): T? {
        return null
    }
    */
     fun myFun3(arg: T) {}
}

fun main() {
    val obj = MyClass<Sub>()
   // val obj2: MyClass<Super> = obj

    val obj3 = MyClass<Super>()
    val obj4: MyClass<Sub> = obj3
}