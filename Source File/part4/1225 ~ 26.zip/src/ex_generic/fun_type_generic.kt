package ex_generic

class MyClass5<T,A>{
    var info : T? = null
    var data : A? = null

    fun myFun(arg: T):A? {
        return data
    }
}