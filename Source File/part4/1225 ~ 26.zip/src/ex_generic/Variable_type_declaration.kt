package ex_generic

class MyClass4<T, A> {
    var info: T? = null
    var data: A? = null
}

fun main() {
    val obj: MyClass4<String, Int> = MyClass4()
    obj.info = "Hello"
    obj.data = 10
}