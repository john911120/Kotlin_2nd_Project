package ex_type_projection


class MyClass1<T>(val data : T) {
    fun myFun(): T {
        return data
    }

    fun myFun2(arg: T) {

    }
    fun myFun3(arg: T) : T {
        return data;
    }
}

fun some1(arg: MyClass1<in Int>) {
    arg.myFun()
    arg.myFun2(10)
    arg.myFun3(10)
}

fun main() {
    some1(MyClass1<Int>(10))
    some1(MyClass1<Number>(10))
}