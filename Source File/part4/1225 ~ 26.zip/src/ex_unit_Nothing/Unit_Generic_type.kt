package ex_unit_Nothing

/*
    Unit타입 활용을 제네릭 타입에서 사용이 가능하다.

    재정의하는 함수의 반환 타입도 String이다. 그런데
    제네릭으로 선언한 인터페이스를 클래스에서 구현하면서 함수를 재정의 할 때 반환 타입을
    명시하고 싶지 않을 때 제네릭 타입으로 Unit으로 지정해주면 된다.
    인터페이스의 함수를 재정의 할 때 반환 타입을 명시하지 않아도 된다.
 */

interface MyInterface<T> {
    fun myFun(): T
}

class MyClass: MyInterface<String> {
    override fun myFun(): String {
        return "hello"
    }
}

class MyClass2: MyInterface<Unit> {
    override fun myFun() {

    }
}