package ex_unit_Nothing

/*
    코틀린의 Unit 타입도 자바의 void와 동일하다

    두 함수는 함수 내부에서 아무런 값도 반환하지 않는다. 즉, 소스에서 return구문을 사용하지 않았다
    따라서 java의 void처럼 Unit은 함수의 반환값이 없다는 것으로 표현하여도 된다. 하지만 차이는 존재한다.

    void는 함수의 반환값이 없다는 것의 일종의 예약어이지만 Unit은 타입이라는 것이 차이이다.
 */

fun myFun1() {}
fun myFun2(): Unit {}