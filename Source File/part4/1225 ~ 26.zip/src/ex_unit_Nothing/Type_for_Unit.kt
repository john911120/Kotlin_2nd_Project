package ex_unit_Nothing
/*
    함수에 아무런 반환 타입을 명시하지 않았기 때문에 Unit으로 자동 지정된다.
    이 함수에는 어떠한 return구문을 사용하지 않았는데 에러가 안나온다.
    즉, Unit이 타입이라는 것이 증거이다.

    데이터 타입에는 데이터를 대입가능하지만 일반 Int, Double이라는 것과는 다르게
    Kotlin.Unit만 대입되는 특수 타입이다.
 */


fun myFun3() { }
fun myFun4():Unit { }

fun myFun5(): Unit {
    return Unit
}

val myVal : Unit = Unit

fun main() {
    println(myFun3())
}