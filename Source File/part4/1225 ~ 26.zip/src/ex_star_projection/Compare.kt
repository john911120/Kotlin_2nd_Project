package ex_star_projection

/*
    <*> <Any?>의 차이

    out 어노테이션을 이용하였으므로 some1()함수에서 add()함수를 호출할 수 없다.
    이용 측에서 out으로 선언하면 제네릭 타입 매개변수가 선언된 함수는 이용이 안되기 때문이다.

    만약 선언측에 제네릭 타입을 <in T>으로 선언하면  <*>, <in Any?>을 의미하지 않는다.
    <in Nothing>으로 이용하는 것과 같다. 그러므로 매개변수 타입이 <T>으로 선언된 함수는 호출 할 수 없다.
    즉, 대입되는 타입을 모른다는 의미이다.
 */
fun some(array: MutableList<Int>) {
    array.add(10)
}
fun some1(array: MutableList<out Any?>) {
   // array.add(10)
}

fun some2(array: MutableList<*>) {
   // array.add(10)
}

fun main() {
    val list1 = mutableListOf<Int>(10, 20)
    some1(list1)

    val list2 = mutableListOf<Int>(10, 20)
    some2(list2)
}