package ex_reflection

import kotlin.reflect.KClass
import kotlin.reflect.full.declaredMemberExtensionProperties
import kotlin.reflect.full.memberProperties

/*
    클래스 레퍼런스를 이용하여 클래스에 선언된 프로퍼티를 분석하는 방법이다. 제공하는 프로퍼티는 다음과 같다.

    val <T : Any> KClass<T>.declaredMemberProperties: Collection<Kproperty<T, *>>
    = 확장 프로퍼티를 제외한 클래스에 선언된 모든 프로퍼티 반환
    val <T : Any> KClass<T>.memberProperties: Collection<Kproperty<T, *>>
    = 확장 프로퍼티를 제외한 클래스와 상위 클래스에 선언된 모든 프로퍼티 반환
    val <T : Any> KClass<T>.declaredMemberExtensionProperties: Collection<Kproperty2<T, *, *>>
    = 클래스에 선언된 확장 프로퍼티 반환
    val <T : Any> KClass<T>.memberExtensionProperties: Collection<Kproperty2<T, *, *>>
    = 상위 클래스 및 현재 클래스의 확장 프로퍼티 반환

    프로퍼티가 많은 이유는 프로퍼티 정보를 상위 클래스의 프로퍼티까지 추출할 것이지 클래스 내부에 선언된 것만
    추출할 것인가? 확장 프로퍼티를 추출할 것인가에 따라 구분 되어있기 때문이다.
 */

open class SuperClass{
    val superVal: Int = 10
}

class myClass(val no: Int): SuperClass(){
    val myVal: String = "hello"

    val String.someVal: String
        get() = "world"
}

fun someFun2(arg: KClass<*>){
    val properties = arg.declaredMemberExtensionProperties
    println("declaredMemberProperties")
    for(property in properties){
        println("${property.name}: ${property.returnType}")
    }

    println("memberProperties...")
    val properties2 = arg.memberProperties
    for(property in properties2){
        println("${property.name}: ${property.returnType}")
    }

    println("declaredMemberExtensionProperties...")
    val properties3 = arg.declaredMemberExtensionProperties
    for(property in properties3){
        println("${property.name}: ${property.returnType}")
    }
}

fun main() {
    someFun(MyClass::class)
}