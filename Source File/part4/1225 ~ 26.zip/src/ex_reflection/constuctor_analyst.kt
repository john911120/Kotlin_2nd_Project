package ex_reflection

import kotlin.reflect.KClass
import kotlin.reflect.full.primaryConstructor

/*
    클래스가 생성자를 포함하고 있는지 생성자의 매개변수는 어찌 선언되어있는지도 중요한분석 중 하나이다.
    val constructors : Collection<KFunction<T>> = 모든 생성자 정보
    val <T:Any> KClass<T>.primaryConstructor: KFunction<T> = 주 생성자 정보

    각각의 생성자를 KFunction타입으로 받아내고 parameters프로퍼티를 이용하여 생성자에 선언된 매개변수를 추출한다.
    매개변수 정보는 KParameter타입으로 전달되며 이 타입의 name, type을 이용하여 매개변수명, 타입 등에 대한 정보를 추출한다.

    또한 코틀린에서는 생성자가 주 생성자와 보조 생성자로 나누어지는데 위에서 설명한 constructors로 추출한 생성자 정보는
    모든 생성자의 정보이고 때로는 주 생성자에 대한 정보를 추출하고 싶을 때 KClass는 primayConstructor 프로퍼티를 그대로
    제공한다.
 */

open class MyClass2(no:Int) {
    constructor(no: Int, name : String): this(10) { }
    constructor(no: Int, Name : String, email:String): this(10) { }
}

fun someFun1(arg: KClass<*>){
    val constructors = arg.constructors
    for(constructor in constructors){
        print("constructor...")
        val parameters = constructor.parameters
        for(parameter in parameters) {
            print("${parameter.name}: ${parameter.type}..")
        }
        println()
    }
    print("primary constructor..")
    val primaryConstructor = arg.primaryConstructor
    if(primaryConstructor != null){
        val parameters = primaryConstructor.parameters
        for(parameter in parameters){
            print("${parameter.name}: ${parameter.type}...")
        }
    }
}

fun main() {
    someFun1(MyClass2::class)
}