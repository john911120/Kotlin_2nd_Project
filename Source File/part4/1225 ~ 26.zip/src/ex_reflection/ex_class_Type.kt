package ex_reflection

import kotlin.reflect.KClass

/*
    <String>을 명시 했으므로 이곳에는 String 클래스의 레퍼런스만 대입 가능하며 다른 클래스의 레퍼런스를 대입하면
    에러가 발생한다. 또한 java클래스의 레퍼런스는 뒤에 String::class.java 처럼 명시해주면 된다.
 */

val myVal1: KClass<String> = String::class

// val myVal2: KClass<String> = Double::class

val myVal3: Class<*> = String::class.java