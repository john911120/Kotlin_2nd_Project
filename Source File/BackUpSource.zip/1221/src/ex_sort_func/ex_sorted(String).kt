package ex_sort_func

fun main() {
    listOf("na","gu","park").sorted()
        .forEach{println(it)}
}