package ex_sort_func

fun main() {
    listOf(7,6,1,3).sorted()
        .forEach{println(it)}
}