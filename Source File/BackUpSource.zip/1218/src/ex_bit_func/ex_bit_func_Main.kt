package ex_bit_func

fun main()
{
    val data1 = 10
    val data2 = 5
    println("data1.shl(data2) : ${data1.shl(data2)}")
    println("data1 shl data2  : ${data1 shl data2}")
}