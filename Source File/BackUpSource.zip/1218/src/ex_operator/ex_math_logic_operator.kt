package ex_operator

// 산술 관련 대입 연산자
fun main()
{
    val data3 = 10
    val data4 = 10
    println(data3 + data4)
    println(data3 - data4)
    println(data3 * data4)
    println(data3 / data4)
    println(data3 % data4)
}