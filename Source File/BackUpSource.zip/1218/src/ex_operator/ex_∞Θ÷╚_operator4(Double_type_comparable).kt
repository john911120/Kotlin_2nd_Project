package ex_operator

// Double 타입 비교
fun main() {
    val double1: Double? = 10.0
    val double2: Double? = 10.0


    println("double1 == double2 is ${double1 == double2}")
    println("double1 === double2 is ${double1 === double2}")

}