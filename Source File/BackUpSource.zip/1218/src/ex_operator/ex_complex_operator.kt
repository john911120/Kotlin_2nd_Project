package ex_operator

// 복합 대입 연산자 예제
fun main() {
    var data = 10
    data += 5
    println(data)
    data -= 5
    println(data)
    data *= 2
    println(data)
    data /= 2
    println(data)
    data %= 5
    println(data)
}