package ex_operator

// 대입 연산자를 이용해서 변수에 데이터를 대입하였다.

fun main()
{
    val data1 = 10
    val data2 = true
    println(data1)
    println(data2)
}