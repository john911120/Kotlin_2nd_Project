package ex_operator

fun main() {
    println("true && true : ${true && true}")
    println("true && false : ${true && false}")
    println("true || true : ${true || true}")
    println("true || false : ${true || false}")
    println("!true : ${!true}")
}