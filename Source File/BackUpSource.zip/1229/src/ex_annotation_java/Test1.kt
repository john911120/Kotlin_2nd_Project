package ex_annotation_java

@JavaAnnotation2(10,strValue = "imma")
class Test1 { }