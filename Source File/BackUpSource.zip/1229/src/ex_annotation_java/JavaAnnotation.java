package ex_annotation_java;

public @interface JavaAnnotation {
    int intValue();
    String stringValue();
}
