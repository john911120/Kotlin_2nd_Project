package ex_annotation_java

@JavaAnnotation3(10, 20, strValue = arrayOf("son","break"))
class Test2 { }