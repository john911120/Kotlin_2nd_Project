package ex_annotation;

public class ex_annotation_property_for_java {
    private int no;

    public final int getNo(){
        return this.no;
    }

    public final void setNo(int var1){
        this.no = var1;
    }
}
