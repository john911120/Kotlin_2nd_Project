package ex_annotation

class Test7{
    var no: Int = 10
}