package ex_annotation

annotation class ex_Using_target_setting

class test {
    @get:TestAnnotation
    var no: Int = 10
}