package ex_nested_class

fun myFun() {
    var no = 0
    class NestedClass() {
        fun nestedFun(){
            no++
        }
    }
}