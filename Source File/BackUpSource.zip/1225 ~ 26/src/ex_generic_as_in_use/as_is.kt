package ex_generic_as_in_use

/*
    제네릭 정보는 컴파일러를 위한 정보이며 완료가 되고나서 실행을 하게 되면 제네릭 정보는
    사라진다. as, is사용에는 주의를 해야한다. 제네릭은 타입과 연관이 있으며 as나 is 연산자도
    타입과 관련된 연산자이다. as는 타입 캐스팅 연산자이고 is는 타입을 점검하는 연산자이다.

     이 소스는 컴파일 에러는 나지 않으나 some()함수를 호출하면서 10을 전달한다면 예외될 것은 없지만
     "hello"를 전달하게 되면 ClassCastException이라는 예외가 발생한다.

     결국 실행 시점에 타입을 점검하지 않다 보니 as에 의해서 형 변환은 가능하나 변환된 데이터를 이요하다가
     에러가 발생하게 된다. 이처럼 제네릭 타입이 실행 시점까지 남아있지 않기 때문에 is, as연산자를 사용할때
     문제가 발생 할 수 있다.
 */

fun some(arg: Any) {
    if(arg is Any) {

    }
    val intVal=arg as Int
    intVal.plus(10)
}

fun main() {
    some(10)
    some("hello")
}