package ex_variance

open class Super {
    open fun sayHello(){
        println("나는 슈퍼 클래스이고 say...Hello라는 메시지를 출력한다.")
    }
}

class Sub: Super() {
    override fun sayHello() {
        println("나는 서브 클래스이고 say...Hello라는 메시지를 출력한다.")
    }
}

fun main() {
    val obj: Super = Sub()
    obj.sayHello()

    val obj2: Sub = obj as Sub
    obj2.sayHello()
}