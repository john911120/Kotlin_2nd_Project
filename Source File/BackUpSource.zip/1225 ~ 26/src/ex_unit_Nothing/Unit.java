package ex_unit_Nothing;

/*
    자바의 Unit과 코틀린의 Unit의 차이
    void는 타입이 아니며 이 함수는 반환값이 없다는 것을 의미하는 예약어이다.
    함수 호출값이 없을 뿐 아니라 void가 타입이 아니어서 println(void)라는 함수가 없다는
    에러 메시지가 나온다.
 */

/*
public class Unit {
    public void javaFun() {}

    public static void main(String[] args) {
        JavaTest jt = new JavaTest();
        System.out.println(obj.javaFun());
    }
}
*/