package ex_unit_Nothing

/*
    Noting은 주로 함수의 반환타입으로 사용이 되며 프로퍼티 타입에 사용이 된다.

    그런데 Nothing타입으로 선언이되면 null만 대입이 가능하다. null은 초기화가 되지 않았다는
    뜻으로 값이 읎다고 말하는 것이다. 값없다고 명시적으로 표시할 때 사용된다.
 */
fun myFun(arg: Nothing?) : Nothing {
    throw Exception()
}

// val myVal : Nothing? = null