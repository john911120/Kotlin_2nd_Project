package ex_inline_reified

/*
    제네릭 타입을 실행 시점에 알아내서 as와 is연산자가 정상적으로 동작하게 하는 방법은
    reified라는 키워드를 사용하면 된다. 형식 타입을 선언 할 때 reified라는 키워드를 쓰면
    이 제네릭 타입은 시행 시점 까지 유지가 되지만 reified라는 인라인 함수에서는 사용이 가능하다.

    만약 제네릭 타입을 <T>으로 선언했다면 컴파일 에러가 발생 하겠지만 <reified T>으로 선언해서
    T타입을 실행 시점까지 유지하므로 is연산자를 사용한 구문이 정상적으로 컴파일되고 실행이 된다.
 */

inline fun <reified T> some(arg: Any) {
    if(arg is T){
        println("true")
    } else {
        println("false")
    }
}

fun main(args: Array<String>) {
    some<String>("hello")
    some<Int>("Hello")
}