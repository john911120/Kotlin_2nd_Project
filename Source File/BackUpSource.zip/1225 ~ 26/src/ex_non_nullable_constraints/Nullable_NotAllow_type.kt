package ex_non_nullable_constraints

/*
    형식 타입을 <T: Any>으로 선언을 하면
    15번 라인 처럼 사용은 가능하지만 Null을 허용하는 팅ㅂ을 지정하려하면 에러가 발생한다.
 */

class MyClass1<T: Any> {
    fun myFun(arg1: T, arg2: T) {
        println(arg1?.equals(arg2))
    }
}

fun main() {
    val obj1 = MyClass1<String>()
    obj1.myFun("Hello","Hell")

    //val obj2 = MyClass1<Int?>()
    //obj2.myFun(null,100)
}