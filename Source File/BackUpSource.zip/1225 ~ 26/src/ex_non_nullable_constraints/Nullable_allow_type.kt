package ex_non_nullable_constraints

class MyClass<T> {
    fun myFun(arg1: T, arg2: T) {
        println(arg1?.equals(arg2))
    }
}

fun main() {
    val obj1 = MyClass<String>()
    obj1.myFun("Hello","Hell")

    val obj2 = MyClass<Int?>()
    obj2.myFun(null,100)
}