package ex_generic
// 제네릭 클래스 선언 및 사용 방법
class MyClass<T> {
    var info : T? = null
}

fun main() {
    val obj1 = MyClass<String>()
    obj1.info = "hello"

    val obj2 = MyClass<Int>()
    obj2.info = 10
}

/*
// 형식 타입 선언 에러
class MyClass1 {
    val info: T? = null
}
 */
