package ex_generic

class MyClass3<AA> {
    var info: AA? = null
}