package ex_generic

class MyClass2<T>(no: T) {
    var info: T? = null
}

fun main() {
    val obj3 = MyClass2<Int>(10)
    obj3.info=20

    val obj4 = MyClass2("Hello")
    obj4.info="world"
}