package ex_generic

fun<T> someFun(arg: T): T? {
    return null
}