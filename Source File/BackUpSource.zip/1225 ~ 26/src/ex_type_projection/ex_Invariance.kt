package ex_type_projection

/*
    invariance는 제네릭 타입의 형 변환을 허용하지 않는다.
    in과 out 어노테이션을 사용하는 것은 같지만 in, out을 사용하는 위치에 따라서 나뉘어진다.
    모든 곳에 Varience가 적용되어서 편리하지만 선언하는 곳이 아닌 이용하는 시점에 Varience를
    명시하고 싶을 때가 있다. 이때도 in, out이라는 어노테이션을 사용한다.
 */

class MyClass<T>(val data : T) {
    fun myFun(): T {
        return data
    }

    fun myFun2(arg: T) {

    }
    fun myFun3(arg: T) : T {
        return data;
    }
}

fun some(arg: MyClass<Number>) {
    arg.myFun()
    arg.myFun2(10)
    arg.myFun3(10)
}

fun main() {
    some(MyClass<Number>(10))
   // some(MyClass<Int>(10))
}