package ex_type_projection

/*
    Varience가 사용되는 사례로 라이브러리에서 제공하는 Array클래스가 있다.
 */

fun copy(from: Array<Int>, to: Array<Int>) {
    for( i in from.indices)
        to[i] = from [i]
}


fun main() {
    val array1 : Array<Int> = arrayOf(1,2,3)
    val array2 = Array<Int>(3){ x -> 0}
    copy(array1, array2)
    array2.forEach { println(it) }
}