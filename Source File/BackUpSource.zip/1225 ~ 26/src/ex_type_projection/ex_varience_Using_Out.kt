package ex_type_projection

/*
    out 어노테이션을 이용해서 varience를 지정할 때 주의해야 할 부분이 있는데
    out으로 선언한 클래스의 함수 이용에 제약이 가해진다. MyClass내에 선언한 함수 중
    매개변수를 제네릭 타입으로 선언한 함수는 사용이 안된다.그러므로 MyClass의 myFun()함수는
    호출할 수 있지만 myFun2, myFun3처럼 매개 변수를 제네릭 타입으로 선언한 함수를 호출하면
    컴파일 에러가 발생한다.
 */

class MyClass2<T>(val data : T) {
    fun myFun(): T {
        return data
    }

    fun myFun2(arg: T) {

    }
    fun myFun3(arg: T) : T {
        return data;
    }
}

fun some2(arg: MyClass1<out Number>) {
    arg.myFun()
    /*
    arg.myFun2(10)
    arg.myFun3(10)
    */
}

fun main() {
    some2(MyClass1<Int>(10))
    some2(MyClass1<Number>(10))
}