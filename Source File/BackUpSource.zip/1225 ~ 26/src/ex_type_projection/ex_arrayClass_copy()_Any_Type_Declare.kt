package ex_type_projection

/*
   다양한 타입의 배열 데이터를 받고자 매개변수를 Array<Any>으로 선언했다.
   그리고 이 매개변수에 Array<Int>타입을 대입해서 이용하겠다는 의도이다.
   결과는 컴파일 에러가 발생한다. Int는 Any의 하위이지만 Array<Int>는
   Array<Any>의 하위가 아니기 때문이다.
 */

fun copy(from: Array<Any>, to: Array<Any>) {
    for( i in from.indices)
        to[i] = from [i]
}


fun main() {
    val array1 : Array<Int> = arrayOf(1,2,3)
    val array2 = Array<Any>(3){ x -> 0}
   // copy(array1, array2)
    array2.forEach { println(it) }
}