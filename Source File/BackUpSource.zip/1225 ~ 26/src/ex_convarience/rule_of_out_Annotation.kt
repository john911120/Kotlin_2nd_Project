package ex_convarience

open class Super1

class Sub1: Super1()

class MyClass1<out T>(val data: T){
    val myVal: T? = null
   // var myVal2: T? = null

    fun myFun(): T {
        return data
    }
  //  fun myFun3(arg: T){}
}
/*
fun main() {
    val obj = MyClass<Sub1>(Sub1())
    val obj2 = MyClass<Super1> = obj

    val obj3 = MyClass<Super1>(Super1())
   // val obj4: MyClass<Sub> = obj3
}
 */