package ex_convarience

/*
    out은 제네릭 형식 타입을 선언할 때 형식 타입명 앞에 추가하는 어노테이션이다.@는 쓰지않지만
    특별한 정보를 추가하기 위한 어노테이션이다.
    out으로 선언한 형식 타입은 하위 타입을 상위 타입으로 사용할 수 있지만 상위 타입을 하위 타입에
    대입은 할 수없다.
 */

open class Super

class Sub: Super()

class MyClass<out T>

fun main() {
    val obj = MyClass<Sub>()
    val obj2: MyClass<Super> = obj

    val obj3 = MyClass<Super>()
    //val obj4: MyClass<Sub> = obj3
}