package ex_convarience

/*
    MutableList, List 모두 제네릭을 활용해서 형식 타입이 선언되어있지만 list에만
    out 어노테이션이 선언되어 있다. 따라서 List<Int>으로 선언한 객체를 List<Number>에 대입
    가능할 수 있겠지만 MutableList<Int>으로 선언한 객체를 MutableList<Number>에 대입 불가능하다.

    MutableList는 가변의 리스트이다. add()를 사용해서 데이터를 추가 할 수 있는데 지정한 제네릭
    타입과 같은 타입의 데이터를 추가 할때는 문제가 없지만 다른 타입의 제네릭이 들어오면...
    내부에서 이에 대한 대응을 못하게 된다. 그래서 초기에 선언한 타입으로만 이용하게 강제 할 수 밖에 없다.
    즉, 좋은 기능을 제공 해주고 싶어도 제공을 못 받게 되었기 때문이다.

    List는 초기 데이터 외에는 추가가 안된다. 그래서 조금 가변적으로 제네릭 타입에 의한 형 변환을 허용 할
    수 있다.

*/
fun main() {
    val mutableList1: MutableList<Int> = mutableListOf(10, 20);
    //val mutableList2: MutableList<Number> = mutableList

    val immutableList : List<Int> = listOf(10, 20)
    val immutableList2: List<Number> = immutableList
}